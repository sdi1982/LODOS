#include "usbdrv.h"

#define PRP_INDEX			12					// ������ ��.
#define PRP_TOTALSECTOR		16					// ������ ��.
#define RW_FLAG				20					// Read���� Write���� �÷��� ������.
#define USB_READ_BUFFER		0x8E000
#define USB_WRITE_BUFFER	0x8F000
#define SIZE_OF_SECTOR		512

#define USB_READ			1
#define USB_WRITE			2


int usb_read_sectors(int nDrv, DWORD dwindex, int nTotalSector, char *pBuff)
{
	int		nLoop;			// INT 31h�� �ؾ��ϴ� Ƚ��.
	int		i;

	nLoop = nTotalSector / 8;
	if (nTotalSector % 8)
		nLoop++;


	*(DWORD*)(BACK_TO_RMODE_ADDR + PRP_TOTALSECTOR) = 8;		// ������ 8����(4KB)�� ����.
	for (i = 0; i < nLoop; i++){
		*(DWORD*)(BACK_TO_RMODE_ADDR + PRP_INDEX) = dwindex + i * 8;
		*(DWORD*)(BACK_TO_RMODE_ADDR + RW_FLAG) = USB_READ;
		_asm INT 31h
			if (*(DWORD*)BACK_TO_RMODE_ADDR)
				return -1;

		if ((nLoop - 1) == i){		// ������ �б��...			
			//DbgPrint("Last read, pBuff : %08X, nSize : %d\r\n", pBuff, (nTotalSector - i * 8) * SIZE_OF_SECTOR);
			memcpy(pBuff, (char*)USB_READ_BUFFER, (nTotalSector - i * 8) * SIZE_OF_SECTOR);

		}else{
			//DbgPrint("pBuff : %08X, nSize : %08X\r\n", pBuff, SIZE_OF_SECTOR * 8);
			memcpy(pBuff, (char*)USB_READ_BUFFER, SIZE_OF_SECTOR * 8);
			pBuff += SIZE_OF_SECTOR * 8;
		}
	}

	return 0;
}
int usb_write_sectors(int nDrv, DWORD dwindex, int nTotalSector, char *pBuff)
{
	int		nLoop;
	int		i;

	nLoop = nTotalSector / 8;
	if (nTotalSector % 8)
		nLoop++;

	for (i = 0; i < nLoop; i++){
		*(DWORD*)(BACK_TO_RMODE_ADDR + PRP_INDEX) = dwindex + i * 8;

		if ((nLoop - 1) == i){		// ������ �����...
			memcpy((char*)USB_WRITE_BUFFER, pBuff, (nTotalSector - i * 8) * SIZE_OF_SECTOR);
			*(DWORD*)(BACK_TO_RMODE_ADDR + PRP_TOTALSECTOR) = nTotalSector - i * 8;
			*(DWORD*)(BACK_TO_RMODE_ADDR + RW_FLAG) = USB_WRITE;						

		}else{
			memcpy((char*)USB_WRITE_BUFFER, pBuff, 8 * SIZE_OF_SECTOR);
			*(DWORD*)(BACK_TO_RMODE_ADDR + PRP_TOTALSECTOR) = 8;
			*(DWORD*)(BACK_TO_RMODE_ADDR + RW_FLAG) = USB_WRITE;			
			pBuff += SIZE_OF_SECTOR * 8;

		}
		_asm INT 31h
			if (*(DWORD*)BACK_TO_RMODE_ADDR)
				return -1;
	}

	return 0;
}