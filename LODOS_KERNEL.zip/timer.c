#include "chobits.h"
extern DWORD m_timeCount;

timer_IRQ_Handler(VOID)
{
	CrtPrintf("timer Interrupt Occurred\r\n");
	m_timeCount++;
}