#ifndef _CTYPE_H_
#define _CTYPE_H_

typedef unsigned int	size_t;

#endif /* #ifndef _CTYPE_H_ */