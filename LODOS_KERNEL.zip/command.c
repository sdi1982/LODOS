#include "file_system.h"
#include "command.h"
#include "filemanager.h"

DWORD m_read_count = 0;
DWORD m_write_count = 0;
DWORD m_usb_read_count = 0;
DWORD m_usb_write_count = 0;

// ���� �б� �׽�Ʈ : ������ ������ �о ȭ�鿡 ����Ѵ�.
KERNELAPI DWORD TYPE(char* path_file)
{
	BYTE		buf[129];
	DWORD		readBytes;
	FILE_STRUCT readFile;
	int	i = 0;
	int	testIndex=0;
	char abs_path[MAX_PATH_LEN];
	int old_drive = 0;
	int src_drive = 0;

	PNTFS_FILE_STRUCT pNtfsReadFile;

	if(m_pCurVOLUME->fat32.isFat32)
	{
		src_drive = getPathVolumeNo(abs_path);
		old_drive = getCurrentVolumeNo();
		if(setCurrentVolume(src_drive) == -1)
			return -1;
		
		if(open_read_file(path_file, &readFile) == -1)
		{
			CrtPrintf("open_read_file() Error!!! \r\n");
			setCurrentVolume(old_drive);
			return -1;
		}

		do
		{                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                       
			readBytes = read_file(&readFile, 128, buf);
			buf[readBytes] = '\0';
			CrtPrintf("%s",buf);
		}while(readBytes != 0);

		close_read_file(&readFile);

		setCurrentVolume(old_drive);
	}
	else
	{
		if(ntfs_open(&pNtfsReadFile,path_file) == -1)
			return -1;

		do
		{                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                          
			readBytes = ntfs_read(pNtfsReadFile, 128, buf);
			// �ι��ڸ� �����Ѵ�.
			buf[readBytes] = '\0';
			CrtPrintf("%s",buf);
			//memset(buf, 0, sizeof(buf));
			//DbgPrint("readBytes: %d \r\n",readBytes);
		}while(readBytes != 0);

		ntfs_close(&pNtfsReadFile);
	}

	return 0;
}

DWORD copy_ntfs_to_fat32(char* src_path, char* dest_path)
{
	PBYTE		pBuf;
	DWORD		readBytes;
	PNTFS_FILE_STRUCT pNtfsReadFile;
	FILE_STRUCT createFile;
	DWORD		tatal_write = 0;
	int			src_drive   = getPathVolumeNo(src_path);
	int			dest_drive  = getPathVolumeNo(dest_path);
	int			old_drive   = getCurrentVolumeNo();
	DWORD start_sector = 0;	

	if(setCurrentVolume(src_drive) == -1)
	{
		DbgPrint("setCurrentVolume() Error!!! \r\n");
		setCurrentVolume(old_drive);
		return -1;
	}

	if(ntfs_open(&pNtfsReadFile,src_path) == -1)
	{
		DbgPrint("ntfs_open() Error!!! \r\n");
		setCurrentVolume(old_drive);
		return -1;
	}

	if(setCurrentVolume(dest_drive) == -1)
	{
		DbgPrint("setCurrentVolume() Error!!! \r\n");
		setCurrentVolume(old_drive);
		return -1;
	}

	if(open_create_file(dest_path, &createFile) == -1)
	{
		DbgPrint("open_create_file() Error!!! \r\n");
		return -1;
	}

	pBuf = (PBYTE)MmAllocateNonCachedMemory(4096);	

	do
	{
		setCurrentVolume(src_drive);
		readBytes = ntfs_read(pNtfsReadFile, 4096, pBuf);

		setCurrentVolume(dest_drive);
		write_file(&createFile,readBytes,pBuf);
	}while(readBytes != 0);

	MmFreeNonCachedMemory(pBuf);

	setCurrentVolume(dest_drive);
	close_create_file(&createFile);

	setCurrentVolume(src_drive);
	ntfs_close(&pNtfsReadFile);

	setCurrentVolume(old_drive);

	return 0;
}

DWORD copy_fat32_to_fat32(char* src_path, char* dest_path)
{
	PBYTE		pBuf;
	DWORD		readBytes;
	DWORD		writeBytes = 0;
	FILE_STRUCT readFile;
	FILE_STRUCT createFile;
	DWORD		tatal_write = 0;
	int			src_drive = getPathVolumeNo(src_path);
	int			dest_drive= getPathVolumeNo(dest_path);
	int			old_drive = getCurrentVolumeNo();
	DWORD start_sector = 0;

	if(setCurrentVolume(src_drive) == -1)
	{
		DbgPrint("setCurrentVolume() Error!!! \r\n");
		setCurrentVolume(old_drive);
		return -1;
	}

	if(open_read_file(src_path, &readFile) == -1)
	{
		DbgPrint("open_read_file() Error!!! \r\n");
		setCurrentVolume(old_drive);
		return -1;
	}


	if(setCurrentVolume(dest_drive) == -1)
	{
		DbgPrint("setCurrentVolume() Error!!! \r\n");
		setCurrentVolume(old_drive);
		return -1;
	}

	if(open_create_file(dest_path, &createFile) == -1)
	{
		DbgPrint("open_create_file() Error!!! \r\n");
		return -1;
	}

	pBuf = (PBYTE)MmAllocateNonCachedMemory(m_pCurVOLUME->fat32.ClusterSize);

	do
	{
		setCurrentVolume(src_drive);
		readBytes = read_file(&readFile, m_pCurVOLUME->fat32.ClusterSize, pBuf);

		setCurrentVolume(dest_drive);
		
		writeBytes = 0;
		do{
			readBytes -= writeBytes;
			writeBytes = write_file(&createFile,readBytes,pBuf);
		}while(readBytes != writeBytes);
	}while(readBytes != 0);

	MmFreeNonCachedMemory(pBuf);

	setCurrentVolume(dest_drive);
	close_create_file(&createFile);

	setCurrentVolume(src_drive);
	close_read_file(&readFile);

	setCurrentVolume(old_drive);

	return 0;
}

KERNELAPI DWORD COPY(char* src_path, char* dest_path)
{
	UINT src_drive = getPathVolumeNo(src_path);
	UINT dest_drive = getPathVolumeNo(dest_path);
	UINT old_drive = getCurrentVolumeNo();

	m_read_count = 0;
	m_write_count = 0;
	m_usb_read_count = 0;
	m_usb_write_count = 0;

	// copy c:/filename.EXE e: or e:/  ����� �Է������� filename.exe�� e:/filename.exe��� �ٿ��ֱ� ���� ��ƾ!
	//if(strlen(dest_abs_path)) //dest_abs_path�� directory�� ���!
	//{
	//	int count=0;
	//	char strTemp[MAX_PATH_LEN]={0};
	//	int src_len = strlen(src_abs_path);
	//	int dest_len = strlen(dest_abs_path);
	//	for(count = src_len-1 ;count>=0 ; count--)
	//	{
	//		if(src_abs_path[count]=='/' && ((count+1) < src_len) )
	//		{
	//			if(dest_abs_path[dest_len-1]=='/') //dest_abs_path�� '/' ������ ��� ���ں��� ����
	//				count++;
	//			// �׷��� ������ '/' ���� ����
	//			memcpy(strTemp,&src_abs_path[count],src_len - count);
	//			strcat(dest_abs_path,strTemp);
	//			break;
	//		}
	//	}
	//}

	// ������(�� ����̹�)�� FAT32�� �ƴϸ� ���� ó��

	if(dest_drive == -1)
	{
		DbgPrint("getPathVolumeNo() \r\n");
		return -1;
	}

	if(m_VOLUME[dest_drive].fat32.isFat32 == 0)
	{
		DbgPrint("dest drive is not formatted FAT32 \r\n");
		return -1;
	}
	
	setCurrentVolume(src_drive);

	if(m_pCurVOLUME->fat32.isFat32)
		copy_fat32_to_fat32(src_path,dest_path);
	else
		copy_ntfs_to_fat32(src_path,dest_path);

	setCurrentVolume(old_drive);
	DbgPrint("hdd_read: %d \r\n",m_read_count);
	DbgPrint("hdd_write: %d \r\n",m_write_count);
	DbgPrint("usb_read: %d \r\n",m_usb_read_count);
	DbgPrint("usb_write: %d \r\n",m_usb_write_count);

	return 0;
}

//KERNELAPI DWORD api_COPY(char* src_path, char* dest_path)
//{
//	PBYTE		pBuf;
//	DWORD		readBytes;
//	FILE_STRUCT readFile;
//	FILE_STRUCT createFile;
//	DWORD		tatal_write = 0;
//	int			src_drive = 0;
//	int			dest_drive= 0;
//	int			old_drive = getCurrentVolumeNo();
//	PNTFS_FILE_STRUCT pNtfsReadFile;
//	char src_abs_path[MAX_PATH_LEN];
//	char dest_abs_path[MAX_PATH_LEN];
//	DWORD start_sector = 0;
//
//
//	m_read_count = 0;
//	m_write_count = 0;
//	m_usb_read_count = 0;
//	m_usb_write_count = 0;
//
//	if(make_absolute_path(src_path , src_abs_path))
//		return -1;
//
//	src_drive = getPathVolumeNo(src_abs_path);
//
//	if(make_absolute_path(dest_path , dest_abs_path))
//		return -1;
//	
//	dest_drive = getPathVolumeNo(dest_abs_path);
//
//	// ������(�� ����̹�)�� FAT32�� �ƴϸ� ���� ó��
//	if(m_VOLUME[dest_drive].fat32.isFat32 == 0)
//		return -1;
//	
//	setCurrentVolume(src_drive);
//
//	if(m_pCurVOLUME->fat32.isFat32)
//	{
//		if(open_read_file(src_abs_path, &readFile) == -1)
//		{
//			setCurrentVolume(old_drive);
//			return -1;
//		}
//	}
//
//	else
//	{
//		if(ntfs_open(&pNtfsReadFile,src_path) == -1)
//		{
//			setCurrentVolume(old_drive);
//			return -1;
//		}
//	}
//
//	setCurrentVolume(dest_drive);
//
//	if(open_create_file(dest_path, &createFile) == -1)
//		return -1;
//	
//	if(m_pCurVOLUME->fat32.isFat32)
//		pBuf = (PBYTE)MmAllocateNonCachedMemory(m_pCurVOLUME->fat32.ClusterSize);
//	else
//		pBuf = (PBYTE)MmAllocateNonCachedMemory(4096);
//
//#ifdef DEBUG_GNAI
//	CrtPrintf("memory assigned!!\r\n");
//#endif
//
//#ifdef DEBUG_GNAI
//	CrtPrintf("m_pCurVOLUME->fat32.isFat32 : %d\r\n", m_pCurVOLUME->fat32.isFat32);
//#endif
//
//	do
//	{
//		setCurrentVolume(src_drive);
//
//
//		if(m_pCurVOLUME->fat32.isFat32)
//			readBytes = read_file(&readFile, m_pCurVOLUME->fat32.ClusterSize, pBuf);
//		else
//			readBytes = ntfs_read(pNtfsReadFile, 4096, pBuf);
//		setCurrentVolume(dest_drive);
//		write_file(&createFile,readBytes,pBuf);
//	}while(readBytes != 0);
//
//	MmFreeNonCachedMemory(pBuf);
//
//	setCurrentVolume(dest_drive);
//	close_create_file(&createFile);
//
//
//	setCurrentVolume(src_drive);
//
//	if(m_pCurVOLUME->fat32.isFat32)	
//		close_read_file(&readFile);
//	else
//		ntfs_close(&pNtfsReadFile);
//
//	setCurrentVolume(old_drive);
//
//	return 0;
//}



KERNELAPI DWORD DIR_0()
{
	DWORD directory_sector = 0;
	
	if(m_pCurVOLUME->fat32.isFat32 == 1)
	{

		directory_sector = get_directory_path_sector(m_pCurVOLUME->CurrentPath);
		if(directory_sector == -1)
			return -1;
		display_dir_entry(directory_sector);
	}
	else
	{
		ntfs_directory_list(m_pCurVOLUME->CurrentPath);
	}
	return 0;
}

KERNELAPI DWORD DIR_1(char* path)
{
	UINT old_drive = 0;
	UINT  src_drive = 0;
	DWORD directory_sector = 0;

	src_drive = getPathVolumeNo(path);
	old_drive = getCurrentVolumeNo();
	
	if(setCurrentVolume(src_drive) == -1)
	{
		CrtPrintf("get_directory_path_sector() Error!!! \r\n");
		setCurrentVolume(old_drive);
		return -1;
	}

	if(m_pCurVOLUME->fat32.isFat32)
	{
		directory_sector = get_directory_path_sector(path);
		if(directory_sector == -1)
		{
			CrtPrintf("get_directory_path_sector() Error!!! \r\n");
			setCurrentVolume(old_drive);
			return -1;
		}

		display_dir_entry(directory_sector);
	}
	else
	{
		// ntfs_make_absolute_path(path,absolute_path);
		ntfs_directory_list(path);
	}

	setCurrentVolume(old_drive);

	return 0;
}

// ���丮�� �����.
// IN char* cur_dir_path	���� ���丮 ���
// IN char* dir_name		���� ���丮 ��
KERNELAPI DWORD MK_DIR(IN char* str_path, char* str_dir)
{
	DWORD directory_sector = 0;
	int nR = 0;
	int old_drive = 0, src_drive = 0;

	if(m_pCurVOLUME->fat32.isFat32 == 0)
		return -1;

	if(strlen(str_path) > MAX_PATH_LEN -1 )
	{
		CrtPrintf("path too big Error!!! \r\n");
		return -1;
	}

	src_drive = getPathVolumeNo(str_path);
	old_drive = getCurrentVolumeNo();
	setCurrentVolume(src_drive);

	directory_sector = get_directory_path_sector(str_path);
	if(directory_sector == -1)
	{
		CrtPrintf("get_directory_path_sector() Error!!! \r\n");
		setCurrentVolume(old_drive);
		return -1;
	}

	if(make_sub_directory(directory_sector,str_dir) == -1)
	{
		CrtPrintf("make_sub_directory() Error!!! \r\n");
		setCurrentVolume(old_drive);
		return -1;
	}
	setCurrentVolume(old_drive);

	return 0;
}

KERNELAPI DWORD RM_DIR(char* str_path, char* str_dir)
{
	DWORD directory_sector = 0;
	int old_drive = 0, src_drive = 0;

	if(m_pCurVOLUME->fat32.isFat32 == 0)
		return -1;

	if(strlen(str_path) > MAX_PATH_LEN -1 )
	{
		CrtPrintf("path too big Error!!! \r\n");
		return -1;
	}

	src_drive = getPathVolumeNo(str_path);
	old_drive = getCurrentVolumeNo();
	setCurrentVolume(src_drive);

	directory_sector = get_directory_path_sector(str_path);
	if(directory_sector == -1)
	{
		CrtPrintf("get_directory_path_sector() Error!!! \r\n");
		setCurrentVolume(old_drive);
		return -1;		
	}


	// ���丮�� ������� ���丮 �ȿ� ������ �ִ��� Ȯ���� �ؾ��Ѵ�.
	if(check_empty_directory(directory_sector, str_dir) == -1)
	{
		CrtPrintf("check_empty_directory() Error!!! \r\n");
		setCurrentVolume(old_drive);
		return -1;
	}

	if(remove_directory_or_file(directory_sector,str_dir) == -1)
	{
		CrtPrintf("remove_directory_or_file() Error!!! \r\n");
		return -1;
	}
	setCurrentVolume(old_drive);

	return 0;
}

KERNELAPI DWORD VOLUME_INFO_0()
{
	display_volume_info(m_pCurVOLUME);

	return 0;
}

KERNELAPI DWORD VOLUME_INFO_1(DWORD drive)
{
	if(drive > m_VolumeNum)
		return -1;

	display_volume_info(&m_VOLUME[drive]);
	return 0;
}

// �ϵ��ũ�� Ư�� ���͸� �����Ѵ�.
// IN int nDrv: ���� �ϵ��ũ ����̺� ��ȣ
// IN DWORD dwIndex: ���� ��ȣ
// IN DWORD len: ����� ����Ʈ�� ���� (512 ����)
KERNELAPI void HDD_DUMP( IN int nDrv, IN DWORD dwIndex, IN DWORD len)
{
	char buf[512];

	if(len > 512)
	{
		CrtPrintf("Too Big Size\r\n");
		return;
	}
	CrtPrintf("hdd_dump Drive: %d Secotr: %d Len: %d\r\n", nDrv, dwIndex, len);
	read_sectors(nDrv,dwIndex,1,buf);
	HexDump(buf,len);
}

KERNELAPI DWORD CD(char* path)
{
	DWORD dir_sector  = 0;
	int old_drive = 0, src_drive = 0;

	if(strlen(path) > MAX_PATH_LEN -1 )
		return -1;

	src_drive = getPathVolumeNo(path);
	old_drive = getCurrentVolumeNo();
	if(setCurrentVolume(src_drive) == -1)
	{
		DbgPrint("setCurrentVolume() Error!!! \r\n");
		setCurrentVolume(old_drive);
		return -1;
	}

	// �߸��� ���� ���...
	if((path[1] != ':') || (path[2] != '/') || (path[strlen(path) - 1] != '/'))
	{
		DbgPrint(": or / Error!!! \r\n");
		setCurrentVolume(old_drive);
		return -1;
	}

	if(m_pCurVOLUME->fat32.isFat32 == 1)
	{ //fat32		
		dir_sector = get_directory_path_sector_attr(path);

		if(dir_sector == -1)
		{
			DbgPrint("get_directory_path_sector() Error!!! \r\n");
			setCurrentVolume(old_drive);
			return -1;
		}
		
		
		if(change_directory(path) == -1)
		{
			DbgPrint("change_directory() Error!!! \r\n");
			setCurrentVolume(old_drive);
			return -1;
		}
	}
	else
	{ //ntfs
		if(ntfs_change_directory(path) == -1)
			return -1;
	}

	//DbgPrint("CurrentPath: %s \r\n",m_pCurVOLUME->CurrentPath);
	
	return 0;
}

//KERNELAPI DWORD api_CD(char* path)
//{
//	char absolute_path[MAX_PATH_LEN]={0};
//
//	if(strlen(path) > MAX_PATH_LEN -1 )
//		return -1;
//
//	if(Absolute_path_Volume_check(path , absolute_path)) //�����η� ���� ��ȯ���� ����� ������ ��Ƽ���� �� fat32=1, ntfs=0 ��.
//	{ //fat32
//		if(get_directory_path_sector(absolute_path) == -1)
//			return -1;
//
//		if(change_directory(absolute_path) == -1)
//			return -1;
//	}
//	else
//	{ //ntfs
//		if(ntfs_change_directory(absolute_path) == -1)
//			return -1;
//	}
//
//	//DbgPrint("CurrentPath: %s \r\n",m_pCurVOLUME->CurrentPath);
//
//	return 0;
//}


// 2007 08 02 ������
KERNELAPI VOID CUR_VOL_STRING(IN char * InString)
{
	memcpy(InString, m_pCurVOLUME->CurrentPath, strlen(m_pCurVOLUME->CurrentPath));
	InString[strlen(m_pCurVOLUME->CurrentPath)]='\0';
	return;
}

