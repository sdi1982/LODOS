#ifndef _EVENT_H_
#define _EVENT_H_

#include "lodos.h"

#define INTERRUPT_CLEAR		0
#define INTERRUPT_OCCURRED	1

typedef unsigned char HEVENT;

extern KERNELAPI DWORD  PsGetTickCount(VOID);

VOID clear_event_count(HEVENT* pEventHandle);
int  wait_event(HEVENT* pEventHandle, DWORD dwTime);
VOID SetEvent(HEVENT* pEventHandle);
VOID SDelay(DWORD dwTime);

#endif