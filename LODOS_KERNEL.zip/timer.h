#ifndef _TIMER_H_
#define _TIMER_H_

timer_IRQ_Handler(VOID);

#endif