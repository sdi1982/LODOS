#ifndef _STRING_H_
#define _STRING_H_

/*
 * INCLUDE FILES
 */
#include "ctype.h"

/*
 * Library functions
 */
extern void* memset(void *pSource, int ch, size_t size);
extern int strcmp(const char *cs, const char *ct);
extern size_t strlen(const char * s);
extern void *memcpy(void *dest, const void *src, size_t count);
extern char *strlwr(char *str);
extern char *strupr(char *str);
extern char * strrchr(const char * s, int c);
extern char * strcpy(char * dest,const char *src);
extern char * strcat(char * dest, const char * src);
extern int is_char(const char ch );
extern int memcmp(const void* pD,const void *pS, int lSize );
extern int  strcmpi(const char *pA,const char *pB );
extern int pow(int num, int exp);
extern int atoi(const char* str);
extern void wcstombs(char* final,const unsigned short* filename, int num);
#endif /* #ifndef _STRING_H_ */