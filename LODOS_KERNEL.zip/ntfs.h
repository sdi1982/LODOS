#ifndef _NTFS_HEADER_FILE_
#define _NTFS_HEADER_FILE_

#define	U64		signed long long
#define	MAX_CLUS_RUN	1000

#pragma pack(1)

typedef struct _NTFS_BOOT_RECORD{
	BYTE		jumpBootCode[3];			// EB 3C 90
	BYTE		OEMName[8];					// "NTFS"
	WORD		BytesPerSector;				// 512
	BYTE		SectorPerCluster;			// 32
	WORD		ReservedSectorCount;		// 32
	BYTE		Unused1[5];	
	BYTE		Media;
	BYTE		Unused2[18];
	U64			TotalSector;	
	U64			StartOfMFT;
	U64			StartOfMFTMirr;
	BYTE		SizeOfMFTEntry;
	BYTE		Unused3[3];
	BYTE		SizeOfIndexRecord;
	BYTE		Unused4[3];	
	U64			SerialNumber;
	DWORD		Unused;
	BYTE		BootCodeArea[426];
	WORD		Signature;

}NTFS_BOOT_RECORD, *PNTFS_BOOT_RECORD;

#pragma pack()

#pragma pack(1)
typedef struct __MFTENTRY_HEADER_STRUCT{
	BYTE		Signature[4];
	WORD		AddrFixUpArray;
	WORD		CountFixUpArray;
	U64			LSN;
	WORD		SeqeunceValue;
	WORD		LinkCnt;
	WORD		AddrFirstAttr;
	WORD		Flags;
	DWORD		UsedSizeOfEntry;
	DWORD		AllocSizeOfEntry;
	U64			FileRefer;
	WORD		NextAttrID;
}MFTENTRY_HEADER, *PMFTENTRY_HEADER;
#pragma pack()

typedef union __MFTEntry{
	MFTENTRY_HEADER Header;
	BYTE				Data[1024];
}MFTENTRY, *PMFTENTRY;

#pragma pack(1)
typedef struct __ATTR_RESIDENT{
	DWORD		AttrSize;
	WORD		AttrOffset;
	BYTE		IndexedFlag;
	BYTE		Padding;
}ATTRRES,*PATTRRES;
#pragma pack()

#pragma pack(1)
typedef struct __ATTR_NON_RESIDENT{
	U64		StartVCNOfRunList;
	U64		EndVCNOfRunList;
	WORD	RunListOffset;
	WORD	CompressUnitSize;
	DWORD	Unused;
	U64		AllocSizeOfAttrContent;
	U64		ActualSizeOfAttrConent;
	U64		InitialSizeOfAttrContet;
}ATTRNONRES, *PATTRNONRES;
#pragma pack()

#pragma pack(1)
typedef struct __ATTR_HEADER{
	DWORD				AttrTypeID;
	DWORD				Length;
	BYTE				non_resident_flag;
	BYTE				LenOfName;
	WORD				OffsetOfName;
	WORD				Flags;
	WORD				AttrID;
	union{
		ATTRRES		Res;		
		ATTRNONRES	NonRes;
	};
}ATTRHEADER, *PATTRHEADER;
#pragma pack()

#pragma pack(1)
typedef struct __ATTR_FILENAME{
	U64					FileReferOfParantDIR;
	U64					CreateTime;
	U64					ModTime;
	U64					MFTmodTime;
	U64					AccTime;
	U64					AllocSize;
	U64					UsedSize;
	DWORD				Flag;
	DWORD				RepaeseValue;
	BYTE				LenOfName;
	BYTE				NameSpace;
	unsigned short		FileName;
}ATTRFILENAME, *PATTRFILENAME;
#pragma pack()

//-----------------------------

#pragma pack(1)
typedef struct __ATTR_INDEX_ROOT{
	DWORD			AttrType;
	DWORD			CollationRule;
	DWORD			IndexRecordSize;
	BYTE			IndexRecordClusSize;
	BYTE			Padding[3];	
}ATTRINDEX_ROOT, *PATTRINDEX_ROOT;
#pragma pack()


#pragma pack(1)
typedef struct __INDEX_RECORD_HEADER{
	BYTE			Sign[4];
	WORD			AddrFixUpArray;
	WORD			CountFixUpArray;
	U64				LSN;
	U64				ThisIndexVCN;
}INDEX_RECORD_HEADER, *PINDEX_RECORD_HEADER;
#pragma pack()	

#pragma pack(1)
typedef struct __NODE_HEADER{
	DWORD			AddrFirstIndex;
	DWORD			UsedSizeOfIndex;
	DWORD			AllocSizeOfIndex;
	BYTE			Flags;
	BYTE			Padding[3];	
}NODEHEADER, *PNODEHEADER;
#pragma pack()	

#pragma pack(1)
typedef struct __INDEX_ENTRY_HEADER{
	U64				FileReferrence;
	WORD			LenOfEntry;
	WORD			LenOfContent;
	WORD			Flags;
}INDEXENTRYHEADER, *PINDEXENTRYHEADER;
#pragma pack()	

typedef struct __RUNDATA{	
	DWORD		Len;
	int			Offset;	
}RUNDATA,*PRUNDATA;


typedef union __INDEX_ENTRY{
	INDEXENTRYHEADER	Header;
	BYTE					Data[];
}INDEXENTRY, *PINDEXENTRY;

typedef struct _NTFS_VOL_STRUCT{
	BYTE		isFat32;				// 07. 14. �߰� 
	DWORD		Drive;
	U64			VolBeginSec;
	U64			MFTStartSec;
	U64			MFTMirrStartSec;
	DWORD		ClusSize;
	DWORD		SecPerClus;
	U64			TotalSec;
	DWORD		SizeOfMFTEntry;
	DWORD		SizeOfIndexRecord;
	//MFTENTRY	CurrentPathMFTEntry;//���� DIRECTROY�� MFT ENTERY�� ������ ����. FIXUP ���� �Ǿ� ����.
}NTFS_VOLUME_STRUCT, *PNTFS_VOLUME_STRUCT;


typedef struct _NTFS_FILE_STRUCT{
	int				volumeNumber;
	DWORD			filePoint;
	ATTRFILENAME	attrFileName;
	MFTENTRY		fileMftEntry;
}NTFS_FILE_STRUCT, *PNTFS_FILE_STRUCT;


DWORD  get_MFTEntry(DWORD MFTNum, MFTENTRY* curMFTEntry, NTFS_VOLUME_STRUCT Vol);
int ChangeFixupData(WORD* data, DWORD ArrayOffset, DWORD AttayCnt,DWORD Size);
void ntfs_read_file(MFTENTRY mft, DWORD  read_start, DWORD read_size, char * read_buf, NTFS_VOLUME_STRUCT Vol);
DWORD  find_file(DWORD MFTNum, char* filename, MFTENTRY* findMft,ATTRFILENAME *pOutAttrFile, NTFS_VOLUME_STRUCT Vol);
U64  fileFile_inNode(BYTE* p, U64* child_vcn, char* filename, ATTRFILENAME *pOutAttrFile);
DWORD get_RunList(BYTE* data, RUNDATA* runData);
DWORD readCluster(U64 vcn, DWORD ClusCnt, RUNDATA* runData, BYTE* buf, NTFS_VOLUME_STRUCT Vol);
void* getAttr(DWORD AttrNum, MFTENTRY* mft);
void ChangetoUpper(char* name);

typedef unsigned short wchar_t; 
//void Lwcstombs(OUT char * multibyte, IN const wchar_t * widebyte , IN unsigned int length);

//�� �Լ��� �����ڵ�16 �߿��� ������ ������.. �ѱ��̸� ����� �ν��� �ȵ�.
void ChangeAnsitoUnicode16(IN char* input, OUT char * output); //ANSI�� 16��Ʈ ���ڷ� ��ȯ
int Unicode16Length(IN char * input);							// 2����Ʈ�� 1���� ���ڷ� �ν�
void PrintStringOn16bit(IN char * input);						// ��Ʈ���� 16bit�� ���
void ChangeUnicode16toAnsi(IN char* input,IN int length, OUT char * output); //16��Ʈ �����ڵ带 ANSI�� ����
void PrintStringOn8bit(IN char * input);		//�� �Լ��� 8��Ʈ ���ڸ� ����ϴ� �Լ���.
void PrintMFTHeader(IN MFTENTRY mft);			//MFT Header ���
BYTE is_NonResident(DWORD AttrNum, MFTENTRY* mft); //�Ӽ��� resident���� non-resident���� �� �� ���� 0 = resident // 1 = non-resident

//directory ���� �Լ�
int get_allPathFile_mft(char* strPath, MFTENTRY *outMFT , ATTRFILENAME *pOutAttrFile , int * volNum); //���� ��θ� ������(����, ���丮 ���) �� ����� MFT�� ��ȯ�Ѵ�. (Fixup�� ������ ������)
DWORD find_file_mft(MFTENTRY mft, char* filename, MFTENTRY* findMft, ATTRFILENAME *pOutAttrFile, NTFS_VOLUME_STRUCT Vol); //DIRECTORY MFT�� ROOT_INDEX ���� DIRECTORY�� �Ҽӵ� ������ �˻��Ѵ�.
DWORD ntfs_make_absolute_path(IN char* str_path, OUT char* abs_path);
DWORD ntfs_change_directory(char* path);
int ntfs_directory_list(char* path);
int ntfs_IndexEntry_filelist(BYTE* p);
int CheckDosFileName(char * strFileName); //DOS ���� �̸����� �ƴ��� �Ǵ��� �ִ� �Լ�
int SearchDot(char * strFileName); //ntfs���Ͽ��� ���� ã�� �Լ�


// open read close seek �ý��� �� �Լ�
int ntfs_open(PNTFS_FILE_STRUCT* filePointer, char * pAllPathFile);
int ntfs_read(PNTFS_FILE_STRUCT filePointer, DWORD read_count, char * buf);
void ntfs_close(PNTFS_FILE_STRUCT *filePointer);
void ntfs_seek(PNTFS_FILE_STRUCT filePointer, int position, BYTE seek_flag);  //SEEK_END�� ��� position���� 


#endif