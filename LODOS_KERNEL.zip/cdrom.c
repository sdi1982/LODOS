#include "cdrom.h"

extern HEVENT	 m_primary_ide_event;
extern HEVENT	 m_secondary_ide_event;

int CheckCDBusy( DWORD dwBasePort )
{
	int		nI;
	UCHAR	uchar;

	// check busy bit
	for( nI = 0; nI < 3; nI++ )
	{	
		uchar =  READ_PORT_UCHAR( CD_STATUS + dwBasePort );
		// busy bit must be 0
		if(( uchar & (UCHAR)0x80 ) == 0 )
			return( 0 );

		KeDelay(30);
	}

	return( -1 );
}

int ReadCDGeometryInfo( CDGeometryStt *pGeo, DWORD dwBasePort, DWORD dwMasterSlave )
{
	int		nI, nR;
	WORD	*pB;
	DWORD	dwTemp;
	UCHAR	cmd[12];
	pB = (WORD*)pGeo;

	memset( pGeo, 0, sizeof( CDGeometryStt ) );

	// check busy bit
	nR = CheckCDBusy( dwBasePort );
	if( nR < 0 )
		return( -1 );

	// clear event count
	if(dwBasePort == PRIMARY_HDD_BASE )
		clear_event_count( &m_primary_ide_event );
	else
		clear_event_count( &m_secondary_ide_event );
	// send IDENTIFY Command
	dwTemp    = (DWORD)( dwMasterSlave << 4 ) | (DWORD)0xE0;  // 1110 0000  LBA Mode
	WRITE_PORT_UCHAR(dwBasePort + CD_DRV_SELECT, (UCHAR)dwTemp );
	WRITE_PORT_UCHAR( CD_COMMAND + dwBasePort, 0xA1 );

	memset( cmd, 0, sizeof(cmd));
	for( nI = 0; nI < sizeof( cmd ) / 2; nI++ )
	{
		WORD *pW;
		pW = (WORD*)&cmd[ nI*2 ];
		WRITE_PORT_UCHAR( CD_DATA+dwBasePort, (UCHAR)pW[0] );
	}

	// wait irq
	if( dwBasePort == PRIMARY_HDD_BASE )
		nR = wait_event( &m_primary_ide_event, 250 );
	else
		nR = wait_event( &m_secondary_ide_event, 250 );
	if(nR == -1)
		return -1;

	// read 512 bytes
	for( nI = 0; nI < 512/2; nI++ )		
		pB[nI] = READ_PORT_WORD( dwBasePort+CD_DATA );

	// check config word  (bit8-12 must be 01001)
	if( (pGeo->wConfig & (WORD)0x1F00 ) != (WORD)0x0500 )
		return( -1 );

	// swap upper and lower	byte
	vSwapWORDArray( pGeo->model,  20 );
	vSwapWORDArray( pGeo->serial, 10 );

	memcpy( pGeo->szSerial, pGeo->serial, 20  );
	memcpy( pGeo->szModel,  pGeo->model,  40 );
	pGeo->szSerial[20] = pGeo->szModel[40] = 0;

	vCutAppendedSpace( pGeo->szSerial );
	vCutAppendedSpace( pGeo->szModel );

	return( 0 );
}
