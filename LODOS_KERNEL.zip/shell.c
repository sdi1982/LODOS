#include "shell.h"
#include "command.h"
#include "usbdrv.h"

static int CMD_DIR		 ( int argc, char *argv[] );
static int CMD_TYPE		 ( int argc, char *argv[] );
static int CMD_MKDIR	 ( int argc, char *argv[] );
static int CMD_RMDIR	 ( int argc, char *argv[] );
static int CMD_HDD_DUMP	 ( int argc, char *argv[] );
static int CMD_VOL		 ( int argc, char *argv[] );
static int CMD_COPY		 ( int argc, char *argv[] );
static int CMD_CD		 ( int argc, char *argv[] );
static int CMD_TCFAT	 ( int argc, char *argv[] );
static int CMD_MEM_DUMP	 ( int argc, char *argv[] );
static int CMD_USB_READ	 ( int argc, char *argv[] );
static int CMD_USB_WRITE ( int argc, char *argv[] );
static int CMD_PS		 ( int argc, char *argv[] );
static int CMD_HELP		 ( int argc, char *argv[] );
static int CMD_MDIR		 ( int argc, char *argv[] );

static int display_help();
static DWORD execute_file(char* path);
static DWORD ShellMainThread(PVOID StartContext);
extern int app_mdir(VOID);

/*
* GLOBAL VARIABLES
*/
static HANDLE m_ProcessHandle, m_ThreadHandle;

#define MAX_CMD_LINE_CHAR			128
static BYTE m_CmdLine[MAX_CMD_LINE_CHAR];

////////////////////////////////////////////

typedef enum {
	JC_UNKNOWN = 0,		JC_LS,
	JC_MKDIR,			JC_TYPE,
	JC_RMDIR,			JC_HDD_DUMP,
	JC_MEM_DUMP,		JC_USB_READ,
	JC_USB_WRITE,		JC_PS,
	JC_VOL_INFO,		JC_COPY,
	JC_CD,				JC_TCFAT,
	JC_HELP,			JC_MDIR,
	END_OF_JC
} JC_TAG;


typedef struct {
	int		nType;
	int		(*pFunc)( int argc, char *argv[] );
	char	*pS;
	char	*pHelp;
} JCStrStt;

static JCStrStt jc[] = {
	{ JC_LS,			CMD_DIR,			"dir",			"list directory entries."	},
	{ JC_MKDIR,			CMD_MKDIR,		"mkdir",		"make new directory."		},
	{ JC_RMDIR,			CMD_RMDIR,		"rmdir",		"remove directory or file"	},
	{ JC_COPY,			CMD_COPY,		"copy",			"copy files."				},
	{ JC_TYPE,			CMD_TYPE,		"type",			"display file's contents."	},
	{ JC_HDD_DUMP,		CMD_HDD_DUMP,	"hdd_dump",		"dump hard disk sector."	},
	{ JC_MEM_DUMP,		CMD_MEM_DUMP,	"mem_dump",		"dump memory sector."		},
	{ JC_VOL_INFO,		CMD_VOL,			"vol",			"display volume information."},
	{ JC_CD,			CMD_CD,			"cd",			"change directory."},
	{ JC_TCFAT,			CMD_TCFAT,		"tcfat",		"read fat table."},
	{ JC_USB_READ,		CMD_USB_READ,	"ur",			"USB read."},
	{ JC_USB_WRITE,		CMD_USB_WRITE,	"uw",			"USB write."},
	{ JC_PS,			CMD_PS,			"ps",			"Process list."},
	{ JC_HELP,			CMD_HELP,		"help",			"help, this command."},
	{ JC_MDIR,			CMD_MDIR,		"mdir",			"mdir."},
	{ 0,				NULL,				NULL	},
};	
///////////////////////////////////////////////
static void *get_jshell_commamd_type( char *pS, int *pType )
{
	int nI;

	*pType = JC_UNKNOWN;

	for( nI = 0; jc[nI].pS != NULL; nI++ )
	{
		if( strcmpi( pS, jc[nI].pS ) == 0 )
		{
			*pType = jc[nI].nType;
			return( jc[nI].pFunc );
		}
	}

	return( NULL );
}

int display_help()
{
	int nI;

	for( nI = 0; jc[nI].nType != 0; nI++ )
		CrtPrintf( "%10s : %s \r\n", jc[nI].pS, jc[nI].pHelp );

	return( 0 );
}

// list directory
static  int CMD_DIR( int argc, char *argv[] )
{
	DWORD nR;

	if(argc == 0)
	{
		nR = DIR_0();
		CrtPrintf( "dir(%s) - %d \r\n",m_pCurVOLUME->CurrentPath, nR );
	}
	else
	{
		nR = DIR_1(argv[0]);
		CrtPrintf( "dir(%s) - %d \r\n", argv[0], nR );
	}

	return( nR );
}

static  int CMD_MKDIR( int argc, char *argv[] )
{
	DWORD nR;

	if( argc < 2 )
	{
		CrtPrintf( "mkdir <path> <dir>\r\n" );
		return( -1 );
	}

	nR = MK_DIR(argv[0], argv[1]);
	CrtPrintf( "mkdir(%s, %s) - %d \r\n", argv[0],argv[1], nR );

	return( nR );
}

static  int CMD_RMDIR( int argc, char *argv[] )
{
	DWORD nR;

	if( argc < 2 )
	{
		CrtPrintf( "rmdir <path> <dir> \r\n" );
		return( -1 );
	}

	nR = RM_DIR(argv[0],argv[1]);
	CrtPrintf( "rmdir(%s, %s) - %d \r\n", argv[0], argv[1], nR );         

	return( nR );
}

static  int CMD_TYPE( int argc, char *argv[] )
{
	DWORD nR;

	if( argc < 1 )
	{
		CrtPrintf( "type <filename>\r\n" );
		return( -1 );
	}

	nR = TYPE(argv[0]);
	CrtPrintf( "type(%s) - %d \r\n", argv[0], nR );

	return( 0 );
}


static  int CMD_HDD_DUMP( int argc, char *argv[] )
{
	if( argc < 3 )
	{
		CrtPrintf( "hdd_dump <drive> <sector> <length> \r\n" );
		return( -1 );
	}

	HDD_DUMP(atoi(argv[0]),atoi(argv[1]), atoi(argv[2]));
	CrtPrintf( "hdd_dump(%d, %d, %d) \r\n",atoi(argv[0]), atoi(argv[1]), atoi(argv[2]));

	return( 0 );
}

static int CMD_MEM_DUMP( int argc, char *argv[] )
{
	int i, j;
	BYTE *pmem;

	if( argc < 1 )
	{
		CrtPrintf( "mem_dump <sector> \r\n" );
		return( -1 );
	}

	pmem = (BYTE*)atoi(argv[0]);

	for (i = 0; i < 512/16; i++){
		for (j = 0; j < 16; j++)
			CrtPrintf("%02X ", *(pmem + i * 16 + j));

		CrtPrintf("  ");

		for (j = 0; j < 16; j++){
			CrtPrintf("%c", *(pmem + i * 16 + j));
		}

		CrtPrintf("\r\n");
	}

	return 0;
}
static int CMD_VOL( int argc, char *argv[] )
{
	DWORD nR;
	if( argc == 0 )
		nR = VOLUME_INFO_0();
	else
		nR = VOLUME_INFO_1(atoi(argv[0]));

	return nR;
}

static int CMD_COPY( int argc, char *argv[] )
{
	DWORD nR;
	if(argc < 2)
	{
		CrtPrintf( "copy <src_path> <dest_paht>\r\n" );
		return( 0 );
	}

	nR = COPY(argv[0],argv[1]);

	return nR;
}

static int CMD_CD( int argc, char *argv[] )
{
	DWORD nR;
	if(argc < 1)
	{
		CrtPrintf( "cd <path> \r\n" );
		return( 0 );
	}

	nR = CD(argv[0]);

	return nR;
}

static int CMD_TCFAT( int argc, char *argv[] )
{
	if(argc < 1)
	{
		CrtPrintf( "rdfat <cluster> \r\n" );
		return( 0 );
	}

	trace_fat_cluster(atoi(argv[0]));

	return 0;
}

static int CMD_USB_READ( int argc, char *argv[] )
{
	if(argc < 3)
	{
		CrtPrintf( "ur <start sector> <size> <mem addr>\r\n" );
		return( 0 );
	}

	// ���� : ���ۼ���, ũ��, �޸� �ּ�
	if (usb_read_sectors(NULL, atoi(argv[0]), atoi(argv[1]), (char*)atoi(argv[2])) == -1)
		CrtPrintf("read error\r\n");

	init_pic_A20();

	return 0;
}

static int CMD_USB_WRITE( int argc, char *argv[] )
{
	if(argc < 3)
	{
		CrtPrintf( "ur <start sector> <size> <mem addr>\r\n" );
		return( 0 );
	}

	// ���� : ���ۼ���, ũ��, �޸� �ּ�
	if(usb_write_sectors(NULL, atoi(argv[0]), atoi(argv[1]), (char*)atoi(argv[2])) == -1)
		CrtPrintf("write error\r\n");

	init_pic_A20();

	return 0;
}

static int CMD_PS( int argc, char *argv[] )
{
	HANDLE hprocess;
	char namebuf[64];

	hprocess = GetFirstProcess();

	CrtPrintf("Handle\tTC\tName\r\n");
	while(1)
	{
		GetProcessName(hprocess, namebuf);
		CrtPrintf("%08X\t%d\t%s\r\n", hprocess, GetThreadCount(hprocess), namebuf);
		hprocess = GetNextProcess(hprocess);
		if (!hprocess)
			break;
	}

	return 0;
}

static int CMD_HELP( int argc, char *argv[] )
{
	display_help();

	return 0;
}
// �Էµ� ���� ��Ʈ���� argv�� �Ľ��Ѵ�.
static int jshell_arg_parsing( char *argv[], char *pS )
{
	int  nTotal, nI, nX;

	nTotal = 0;
	for( nI = 0; pS[nI] != 0; nI++ )
	{
		if( nI == 0 && pS[0] != ' ')
			argv[nTotal++] = pS;
		else
		{
			if( pS[nI-1] == ' ' && pS[nI] != ' ' )
				argv[nTotal++] = &pS[nI];
		}	
	}

	for( nX = 1; nX < nI; nX++ )
	{
		if( pS[nX-1] != ' ' && pS[nX] == ' ' )
			pS[nX] = 0;
	} 

	return( nTotal );
}


// display jshell prompt
int display_prompt()
{
	// ������Ʈ�� �����Ѵ�.
	char drive = 'c' + (int)getCurrentVolumeNo();
	CrtPrintf( "%s>>", m_pCurVOLUME->CurrentPath );

	return(0);
}

#define MAX_JCOMMAND_ARGV	32

// �Էµ� ������ �����Ѵ�.
int execute_command( char *pCmdStr )
{
	int		argc, nResult;
	int		nType;
	char	*argv[ MAX_JCOMMAND_ARGV ];
	int		(*pFunc)( int argc, char *argv[] );
	HANDLE	UserThread;

	nResult = 0;

	if(pCmdStr[0] == NULL)
		return 0;

	// Parsing�Ѵ�.
	argc = jshell_arg_parsing( argv, pCmdStr );

	//Parsing�� ���� �´��� ����� ����.
	//CrtPrintf( "argc = %d \r\n", argc );
	//{
	//	int nI;
	//	for( nI = 0; nI < argc; nI++ )
	//	CrtPrintf( "argv[%d] : %s \r\n", nI, argv[nI] );
	//}

	if( argc == 0 )		// �Էµ� ���� ����.
		return( 0 );

	// ������ Ÿ���� ���Ѵ�.
	pFunc = get_jshell_commamd_type( argv[0], &nType );

	// �Լ��� �����ϸ� CALL�Ѵ�.
	if( pFunc != NULL )
	{
		nResult = pFunc( argc-1, &argv[1] );
		// Ű���� �����۵��� ���ؼ�...
		init_pic_A20();
	}
	else
	{
		nResult = execute_file(argv[0]);
		// �ܺ� ���� ����.
		if (nResult)
			return ( nResult );

		if(!PsCreateUserThread(&UserThread, PsGetParentProcess(PsGetCurrentThread()), NULL)) {			
			return 0;
		}
		PsSetThreadStatus(UserThread, THREAD_STATUS_READY);
		while(PsGetThreadStatus(UserThread) != THREAD_STATUS_TERMINATED) {
			HalTaskSwitch();
		}
		PsDeleteThread(UserThread);
	}

	return( nResult );			// shell���� ��� ������ ����.
}

DWORD execute_file(char* path_file)
{
	BYTE		buf[1024];
	DWORD		total_read = 0;
	DWORD		readBytes;
	FILE_STRUCT readFile;
	int	i = 0;
	int	testIndex=0;
	char abs_path[MAX_PATH_LEN]={0};
	char cur_path[MAX_PATH_LEN]={0};
	int old_drive = 0;
	int src_drive = 0;

	PNTFS_FILE_STRUCT pNtfsReadFile;
	HANDLE UserThread;

	DWORD dest_mem = 0x100000;

	//2007 08 06 
	//���� �ٸ� ������ ������ �����ų���� �Ѵٸ�.. �ű⿡ ���� ó���� �ʿ���!

	//if(m_pCurVOLUME->fat32.isFat32)
	strcpy(cur_path, path_file);
	if(Absolute_path_Volume_check(cur_path,abs_path))
	{
		if(is_filename(path_file) == -1)
		{
			CrtPrintf("is_filename() Error!!! \r\n");
			return -1;
		}

		if(make_absolute_path(path_file,abs_path) == -1)
		{
			CrtPrintf("make_absolute_path() Error!!! \r\n");
			return -1;
		}

		src_drive = getPathVolumeNo(path_file);
		old_drive = getCurrentVolumeNo();
		setCurrentVolume(src_drive);
		if(open_read_file(abs_path, &readFile) == -1)
		{
			CrtPrintf("open_read_file() Error!!! \r\n");
			setCurrentVolume(old_drive);
			return -1;
		}

		total_read += read_file(&readFile, 2, buf);
		if((buf[0] != 'M') && (buf[1] != 'Z'))
		{
			close_read_file(&readFile);
			setCurrentVolume(old_drive);
			return -1;
		}

		total_read = 0;
CrtPrintf("before readfile\r\n");
		do
		{                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                       
			readBytes = read_file(&readFile,1024, (PBYTE)(dest_mem+total_read));
			total_read += readBytes;

			CrtPrintf("readfile %d\r\n", total_read);

			if(total_read >= 1024*1024)
			{
				close_read_file(&readFile);
				setCurrentVolume(old_drive);
				return -1;
			}

		}while(readBytes != 0);
		
CrtPrintf("after readfile\r\n");

		close_read_file(&readFile);
		setCurrentVolume(old_drive);
	}
	else
	{
		if(ntfs_open(&pNtfsReadFile,path_file) == -1)
			return -1;
		do
		{                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                          
			readBytes = ntfs_read(pNtfsReadFile, 128, buf);
			total_read += readBytes;
			memcpy((char*)(dest_mem+total_read),buf,readBytes);
		}while(readBytes != 0);

		ntfs_close(&pNtfsReadFile);
	}	

	// ���⿡ ������ ���� �ڵ� �߰�.
	if(!PsCreateUserThread(&UserThread, PsGetParentProcess(PsGetCurrentThread()), NULL)) {		
		return -1;
	}

CrtPrintf("thread : %08X\r\n", UserThread);
	PsSetThreadStatus(UserThread, THREAD_STATUS_READY);
CrtPrintf("status\r\n");
	while(PsGetThreadStatus(UserThread) != THREAD_STATUS_TERMINATED) {
		HalTaskSwitch();
	}
CrtPrintf("tttt\r\n");
	PsDeleteThread(UserThread);

	init_pic_A20();
	return 0;
}

static  int CMD_MDIR( int argc, char *argv[] )
{
	app_mdir();
	return 0;
}

BOOL InitializeShell(VOID) 
{
	memset(m_CmdLine, NULL, MAX_CMD_LINE_CHAR);

	/* create hideki-shell process */ 
	if(!PsCreateProcess(&m_ProcessHandle, "Shell")) 
		return FALSE;

	/* create main thread */
	if(!PsCreateThread(&m_ThreadHandle, m_ProcessHandle, ShellMainThread, NULL, DEFAULT_STACK_SIZE, FALSE))   
		// ���⼭ ���� ���������� �ϵ��ũ�� ���� �ȴ�.
		return FALSE;
	PsSetThreadStatus(m_ThreadHandle, THREAD_STATUS_READY); /* i'm ready! */

	return TRUE;
}

static DWORD ShellMainThread(PVOID StartContext)
{
	KBD_KEY_DATA KeyData;
	//BYTE cursor_x, cursor_y;
	static int cmd_next_pos=0;

	int nR = 0;
	/* initialized file system */
	//if(!FsInitializeModule()) {
	//	DbgPrint("FsInitializeModule() returned an error.\r\n");
	//	return 0;
	//}

	//	if(init_fat32_file_system() == -1){  // �ϴ� ���⿡�� fat32�� �ʱ�ȭ�� ���� �ȴ�. 

	//gnai>>
	if(init_file_system() == -1){  // �ϴ� ���⿡�� File system �ʱ�ȭ�� ���۵ȴ�.
		//gnai<<
		DbgPrint("init_file_system() returned an error.\r\n");
		return 0;
	}

	display_prompt();
	while(1) {
		if(!KbdGetKey(&KeyData)) {
			HalTaskSwitch();
			continue;
		}

		if(KeyData.type != KBD_KTYPE_GENERAL) {
			continue;
		}

		if(KeyData.key == '\b') { /* backspace? */
			//CrtGetCursorPos(&cursor_x, &cursor_y);
			//if(cursor_x <= strlen(m_pCurVOLUME->CurrentPath) + 2) 
			//	continue;
			if(cmd_next_pos < 1) 
				continue;
			m_CmdLine[--cmd_next_pos] = NULL;
		}

		CrtPrintf("%c", KeyData.key); /* echo */
		/* excute command */
		if(KeyData.key == '\r') {
			m_CmdLine[cmd_next_pos] = NULL;
			if(execute_command(m_CmdLine) == -1)
				CrtPrintf("Bad Command \r\n");
			display_prompt();
			cmd_next_pos = 0;
			m_CmdLine[0] = NULL;
		} 
		/* converts tab key to space key */
		else if(KeyData.key == '\t') {
			m_CmdLine[cmd_next_pos++] = ' ';
		}
		/* inserts a key into the internal command line array */
		else if(KeyData.key != '\b') { /* except BACKSPACE */
			m_CmdLine[cmd_next_pos++] = KeyData.key;
		}
	}

	return 0;
}

