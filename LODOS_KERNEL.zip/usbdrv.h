#ifndef _USB_DRIVER_HEADER_FILE_
#define _USB_DRIVER_HEADER_FILE_

/**********************************************************************************************************
*                                                INCLUDE FILES                                           *
**********************************************************************************************************/

#include "lodos.h"


/**********************************************************************************************************
*                                               DIRVER FUNCTIONS                                         *
**********************************************************************************************************/
int usb_read_sectors(int nDrv, DWORD dwindex, int nTotalSector, char *pBuff);
int usb_write_sectors(int nDrv, DWORD dwindex, int nTotalSector, char *pBuff);


#endif // #ifndef _USB_DRIVER_HEADER_FILE_