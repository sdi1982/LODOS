#include "lodos.h"

/************************************************************************/
/* LODOS OPERATRING	SYSTEM   						                    */
/* FOR	RECOVERY									    				*/
/* USING USB															*/
/************************************************************************/
extern BOOL KrnInitializeKernel(VOID);
extern BOOL CrtInitializeDriver(VOID);
extern BOOL KbdInitializeDriver(VOID);
extern BOOL FddInitializeDriver(VOID);
extern BOOL InitializeShell(VOID);

static void halt(char *pMsg);

DWORD m_timeCount = 0;

int lodos_init(void)
{
	if(!CrtInitializeDriver())		{ halt(NULL); }
	if(!KrnInitializeKernel())		{ halt("KrnInitializeKernel() returned an error.\r\n"); }
	if(!KbdInitializeDriver())		{ halt("KbdInitializeDriver() returned an error.\r\n"); }
	if(!InitializeShell())			{ halt("InitializeShell() returned an error.\r\n"); }

	/* make the first task-switching */
	_asm {
		push	eax

		pushfd
		pop		eax
		or		ah, 40h ; nested
		push	eax
		popfd

		pop		eax
		iretd
	}

	halt("LODOS OS Booting ERROR!!\r\n");
	return 0;
}

static void halt(char *pMsg)
{
	if(pMsg != NULL) {
		DbgPrint(pMsg);
		DbgPrint("Halting system...\r\n");
	}
	while(1) ;
}