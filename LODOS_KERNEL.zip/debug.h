#ifndef _DEBUG_H_
#define _DEBUG_H_


/*
 * INCLUDE FILES
 */
#include "6845crt.h"


/*
 * DEBUG DEFINITIONS
 */
#ifdef __DEBUG__
#define DbgPrint			CrtPrintf
#endif

#ifndef __DEBUG__
#define DbgPrint			CrtPrintf2
#endif


#endif /* #ifndef _DEBUG_H_ */