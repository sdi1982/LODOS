#ifndef _SHELL_H_
#define _SHELL_H_

#include "lodos.h"

extern int display_help();
extern int display_prompt();
extern int execute_command( char *pCmdStr );
extern DWORD search_exe_file(DWORD dir_sector, char* entry_name);
extern BOOL InitializeShell(VOID);

#endif