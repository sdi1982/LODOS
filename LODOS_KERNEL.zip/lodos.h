#ifndef _LODOS_H_
#define _LODOS_H_

/* common */
#include "types.h"
#include "debug.h"
#include "video_def.h"

/* libraries */
#include "string.h"
#include "vsprintf.h"
#include "event.h"

/* device drivers */
#include "6845crt.h"
#include "kbddrv.h"
#include "hdddrv.h"
#include "cdrom.h"
#include "vgadrv.h"

/* graphic library */
#include "directy.h"

/* shell */
#include "file_system.h"


/**********************************************************************************************************
 *                                               DEFINITIONS                                              *
 **********************************************************************************************************/
#define LODOS_OS_VER			"2007 08 09"
#define BACK_TO_RMODE_ADDR		0x80000							// ������� ���ư��� �ּ�.


/**********************************************************************************************************
 *                                                     HAL                                                *
 **********************************************************************************************************/
/* x86 system specific */
#define ENTER_CRITICAL_SECTION()	__asm	PUSHFD	__asm CLI
#define EXIT_CRITICAL_SECTION()		__asm	POPFD

/* These following functions are programmed in hal_asm.asm file. */
extern KERNELAPI UCHAR READ_PORT_UCHAR(IN DWORD Port);
extern KERNELAPI WORD READ_PORT_WORD(IN DWORD Port);
extern KERNELAPI DWORD READ_PORT_DWORD(IN DWORD Port);
extern KERNELAPI VOID WRITE_PORT_UCHAR(IN DWORD Port, IN UCHAR Value);
extern KERNELAPI VOID WRITE_PORT_WORD(IN DWORD Port, IN WORD Value);
extern KERNELAPI VOID WRITE_PORT_DWORD(IN DWORD Port, IN DWORD Value);
extern KERNELAPI VOID HalTaskSwitch(VOID);

extern VOID			vReadPortMultiWord(DWORD dwPort, WORD* pWord, DWORD dwWords);
extern VOID			vWritePortMultiWord(DWORD dwPort, WORD* pWord, DWORD dwWords);
extern HANDLE		GetFirstProcess(void);
extern BOOL			GetProcessName(HANDLE hprocess, char *pbuf);		// ���μ��� �̸� ���.
extern HANDLE		GetNextProcess(HANDLE hprocess);					// ���� ���μ��� �ڵ� ���.
extern int			GetThreadCount(HANDLE hprocess);					// ���μ��� ���� ������ �� ���.
extern int			usb_read_sectors(int nDrv, DWORD dwindex, int nTotalSector, char *pBuff);
extern int			usb_write_sectors(int nDrv, DWORD dwindex, int nTotalSector, char *pBuff);
extern BOOL			init_pic_A20(VOID);


/**********************************************************************************************************
 *                                                   KERNEL                                               *
 **********************************************************************************************************/
KERNELAPI VOID KeDelay(DWORD MilliSec); /* 1000 milli = 1 sec */


/**********************************************************************************************************
 *                                               Process Manager                                          *
 **********************************************************************************************************/
typedef DWORD (*PKSTART_ROUTINE)(PVOID StartContext);

typedef enum _THREAD_STATUS {
	THREAD_STATUS_STOP,			/* dont schedule or excute */
	THREAD_STATUS_TERMINATED,	/* thread has been terminated */
	THREAD_STATUS_READY,
	THREAD_STATUS_WAITING,
	THREAD_STATUS_RUNNING,		/* only one thread of all can be assinged with this status */
} THREAD_STATUS;

KERNELAPI BOOL	 PsCreateProcess(OUT PHANDLE ProcessHandle, char *pname);
KERNELAPI HANDLE PsGetParentProcess(IN HANDLE ThreadHandle);
KERNELAPI BOOL   PsDeleteProcess(IN HANDLE ProcessHandle);
KERNELAPI BOOL   PsCreateThread(OUT PHANDLE ThreadHandle, IN HANDLE ProcessHandle, IN PKSTART_ROUTINE StartRoutine,
								IN PVOID StartContext, IN DWORD StackSize, IN BOOL AutoDelete);
KERNELAPI BOOL   PsCreateIntThread(OUT PHANDLE ThreadHandle, IN HANDLE ProcessHandle, IN PKSTART_ROUTINE StartRoutine,
								   IN PVOID StartContext, IN DWORD StackSize);
KERNELAPI BOOL   PsCreateUserThread(OUT PHANDLE ThreadHandle, IN HANDLE ProcessHandle, IN PVOID StartContext);
KERNELAPI BOOL   PsDeleteThread(IN HANDLE ThreadHandle);
KERNELAPI HANDLE PsGetCurrentThread(VOID);
KERNELAPI BOOL   PsSetThreadStatus(IN HANDLE ThreadHandle, IN THREAD_STATUS Status);
KERNELAPI THREAD_STATUS PsGetThreadStatus(IN HANDLE ThreadHandle);
KERNELAPI BOOL   PsShowTSWachdogClock(BOOL Show);
KERNELAPI DWORD  hPsGetTickCount(VOID);
KERNELAPI DWORD  PsGetMilliSec(DWORD TickCount);


/**********************************************************************************************************
 *                                                Memory Manager                                          *
 **********************************************************************************************************/
KERNELAPI VOID *MmAllocateNonCachedMemory(IN ULONG NumberOfBytes);
KERNELAPI VOID  MmFreeNonCachedMemory(IN PVOID BaseAddress);


#endif /* #ifndef _LODOS_H_ */