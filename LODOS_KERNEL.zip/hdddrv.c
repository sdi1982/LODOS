#include "Hdddrv.h"
extern DWORD m_read_count;
extern DWORD m_write_count;
extern DWORD m_usb_read_count;
extern DWORD m_usb_write_count;


/*
* GLOBAL VARIABLES
*/
HEVENT	 m_primary_ide_event;
HEVENT	 m_secondary_ide_event;

static IDEGeometryStt m_IDEGeo[4];

extern int ReadCDGeometryInfo( CDGeometryStt *pGeo, DWORD dwBasePort, DWORD dwMasterSlave );
extern int CheckCDBusy( DWORD dwBasePort );


/**********************************************************************************************************
*                                             GLOBAL FUNTIONS                                            *
**********************************************************************************************************/

VOID Hdd_Primary_IRQ_Handler(VOID)
{
	//SetEvent(&m_primary_ide_event);
	m_primary_ide_event = TRUE;
	//DbgPrint("HDD interrupt Occurred\r\n");
}


VOID Hdd_Secondary_IRQ_Handler(VOID)
{
	//SetEvent(&m_primary_ide_event);
	m_secondary_ide_event = TRUE;
	//DbgPrint("HDD interrupt Occurred\r\n");
}

static int CheckIDEHddBusy( DWORD dwBasePort )
{
	int 	nI;
	UCHAR 	uchar;
	DWORD	count = 0;

	// check busy bit
	for( nI = 0; nI < 3; nI++ )
	{	
		if( nI >= 3 )
			return -1;

		uchar = READ_PORT_UCHAR( dwBasePort + HDD_STATUS  );
		// busy bit must be 0
		if(( uchar & (UCHAR)0x80 ) == 0 )
			break;

		KeDelay(30);
	}
	return 0;
}

static int GetUDMASetNumber( IDEGeometryStt *pGeo )
{
	if( pGeo == NULL )
		return( -1 );

	if( ( pGeo->wAvailableBit & 4 ) == 0 )		// 88 word is not available
		return( -2 );

	if( pGeo->wUDMAFlag & UDMA_MODE_4_SET )
		return( 4 );
	else if( pGeo->wUDMAFlag & UDMA_MODE_3_SET )
		return( 3 );
	else if( pGeo->wUDMAFlag & UDMA_MODE_2_SET )
		return( 2 );
	else if( pGeo->wUDMAFlag & UDMA_MODE_1_SET )
		return( 1 );
	else if( pGeo->wUDMAFlag & UDMA_MODE_0_SET )
		return( 0 );

	return( -1 );
}

static int GetUDMASupportNumber( IDEGeometryStt *pGeo )
{
	if( pGeo == NULL )
		return( -1 );

	if( ( pGeo->wAvailableBit & 4 ) == 0 )		// 88 word is not available
		return( -2 );

	if( pGeo->wUDMAFlag & UDMA_MODE_4_SUPPORTED )
		return( 4 );
	else if( pGeo->wUDMAFlag & UDMA_MODE_3_SUPPORTED )
		return( 3 );
	else if( pGeo->wUDMAFlag & UDMA_MODE_2_SUPPORTED )
		return( 2 );
	else if( pGeo->wUDMAFlag & UDMA_MODE_1_SUPPORTED )
		return( 1 );
	else if( pGeo->wUDMAFlag & UDMA_MODE_0_SUPPORTED )
		return( 0 );

	return( -1 );
}

void vSwapWORDArray( WORD *pW, int nTotal )
{
	int		nI;
	UCHAR	*pB, byTemp;

	for( nI = 0; nI < nTotal ; nI++ )
	{
		pB     = (UCHAR*)&pW[nI];
		byTemp = pB[0];
		pB[0]  = pB[1];
		pB[1]  = byTemp;
	}		   
}
// ��Ʈ���� �ڿ� �پ��ִ� �����̽��� ���ش�.
void vCutAppendedSpace( char *pS )
{
	int nI;

	for( nI = strlen( pS ) -1; nI > 0; nI-- )
	{
		if( pS[nI] == ' ' )
			pS[nI] = 0;
		else 
			break;
	}
}

// read geometry information
static int  ReadHDDGeometryInfo( IDEGeometryStt *pGeo, DWORD dwBasePort, DWORD dwMasterSlave )
{
	WORD*	pB;
	int		nI, nR;

	DWORD	dwTemp;

	DWORD	count = 0;

	pB = (WORD*)pGeo;

	memset( pGeo, 0, sizeof( IDEGeometryStt ) );

	CheckIDEHddBusy( dwBasePort );
	// wait IRQ
	// �� Halp_IRQ_HardDrive�� �߻��� ������???
	// Answer -- ��� �ϵ��ũ�� �����ϱ� �߻�������...  [5/21/2007]
	// �ٵ� �̻��ϰ� �˻����ϰ� �߻���???
	// ������ �ȿ� �������ϱ�..�׽�ũ ����Ī�� �߻��� ������ ó�� �����ݿ�..
	if(dwBasePort == PRIMARY_HDD_BASE )
		clear_event_count( &m_primary_ide_event );
	else
		clear_event_count( &m_secondary_ide_event );

	dwTemp    = (DWORD)( dwMasterSlave << 4 ) | (DWORD)0xE0;  // 1110 0000  LBA Mode
	WRITE_PORT_UCHAR( dwBasePort + HDD_DRIVE_HEAD, (UCHAR)dwTemp );
	// Send Identify Command	
	WRITE_PORT_UCHAR(dwBasePort + HDD_COMMAND, HDD_IDENTIFY_COMMAND );

	// wait irq
	if( dwBasePort == PRIMARY_HDD_BASE )
		nR = wait_event( &m_primary_ide_event, 250 );
	else
		nR = wait_event( &m_secondary_ide_event, 250 );
	if(nR == -1)
		return -1;

	// read 256 words
	for( nI = 0; nI < 512/2; nI++ )
		pB[nI] = READ_PORT_WORD(dwBasePort+HDD_DATA);
	if( pGeo->wConfig == 0 )
		return( -1 );		// failed!

	// ���� ����Ʈ �ϳ��� �д´�. (2003-04-25)
	//for( nI = 0; nI < 5; nI++ )
	//uchar = READ_PORT_UCHAR(dwBasePort+HDD_STATUS);
	//CrtPrintf( "HDD-GEO Status Byte : 0x%X\n", byTe );

	// swap upper and lower	byte
	vSwapWORDArray( pGeo->manufacturer, 3 );
	vSwapWORDArray( pGeo->model,  20 );

	memcpy( pGeo->szManufacturer, pGeo->manufacturer, 6  );
	memcpy( pGeo->szModel,        pGeo->model,       40 );
	pGeo->szManufacturer[6] = pGeo->szModel[40] = 0;
	// ���ڷ� �������� ������ �ƴ� ������ ����.
	if( is_char( pGeo->szModel[0] ) == 0 || pGeo->szModel[1] == 127 )
		return( -1 );

	vCutAppendedSpace( pGeo->szManufacturer );
	vCutAppendedSpace( pGeo->szModel );

	// calculate size by MB.
	//pGeo->dwSize = (DWORD)( pGeo->wCylinder * pGeo->wHead * pGeo->wSector ) / (2*1024);
	pGeo->dwSize = (DWORD)( (WORD)(pGeo->wLBASectors1 >> 11) | (WORD)(pGeo->wLBASectors2 << 5) );// * 1024 / 1000;

	return( 0 );
}

// ���: �ϵ� ��ũ�� �˻��Ѵ�.
// ����: �˻��� �ϵ��ũ�� ��
UINT IDEAutoDetection(VOID)
{
	IDEGeometryStt	*pGeo;
	CDGeometryStt	cd_geo;

	char			*title[4];
	int				nR, nI;
	DWORD			base_port[4];
	DWORD			master_slave[4];
	UINT			nHDD = 0;	// �˻��� �ϵ� ��ũ�� ��

	CrtPrintf( "IDE HDD Auto detection.\r\n" );

	title[0] = "Primary   Master";
	title[1] = "Primary   Slave ";
	title[2] = "Secondary Master";
	title[3] = "Secondary Slave ";

	base_port[0] = PRIMARY_HDD_BASE;
	base_port[1] = PRIMARY_HDD_BASE;
	base_port[2] = SECONDARY_HDD_BASE;
	base_port[3] = SECONDARY_HDD_BASE;

	master_slave[0] = 0;
	master_slave[1] = 1;
	master_slave[2] = 0;
	master_slave[3] = 1;

	for( nI = 0; nI < 4; nI++ )
	{
		CrtPrintf( "%s: ", title[nI] );

		pGeo = &m_IDEGeo[nI];

		// find hdd
		nR = ReadHDDGeometryInfo( pGeo, base_port[nI], master_slave[nI] );
		if( nR >= 0 )
		{
			int nDma, nDmaSupport;

			// ���� UDMA ��� ���� ���¸� ����Ѵ�.
			nDma = GetUDMASetNumber( pGeo );
			nDmaSupport = GetUDMASupportNumber( pGeo );
			CrtPrintf( "%s UDMA(cur=%d/%d support)\r\n", pGeo->szModel, nDma, nDmaSupport );

			// �˻��� �ϵ��ũ�� ���� ������Ų��.
			nHDD++;
		}
		else
		{// find cd-rom
			nR = ReadCDGeometryInfo( &cd_geo, base_port[nI], master_slave[nI] );
			if( nR >= 0 )
				CrtPrintf( "%s (%s)\r\n", cd_geo.szModel, cd_geo.szSerial );
			else
				CrtPrintf( "None\r\n" );
		}
	}

	CrtPrintf("------------------------\r\n");

	return( nHDD );

}
/************************************************************************/
/* read_sector                                                          */
/************************************************************************/
/** 2003-05-15
*
* VMWare���� ������ �Ϸ� ���ͷ�Ʈ�� �ɸ��� �ʰ� timeout�� �߻��Ѵ�.
* �������� �ʴ� �����̱� ������ �׷����ΰ�? (������ �ʿ䰡 �������� �ְ���.)
* �ϴ� ������� �ʰ� ������.
**/
static int seek_hdd( CHSStt *pCHS )
{
	BYTE 	byTe;
	DWORD	dwTemp;
	int		nI, nR;

	// check busy bit
	for( nI = 0; ; nI++ )
	{	
		if( nI >= 3 )
		{
			CrtPrintf( "HDD seek failed : port is busy.\n" );
			return( -1 );
		}
		byTe = READ_PORT_UCHAR( (DWORD)(HDD_STATUS + pCHS->dwBasePort));
		// busy bit must be 0
		if((  byTe & (UCHAR)0x80 ) == 0 )
			break;		

		SDelay( 30 );
	}

	// send seek parameter
	WRITE_PORT_UCHAR( (DWORD)( pCHS->dwBasePort + HDD_SECTOR_COUNT),  1 );
	WRITE_PORT_UCHAR( (DWORD)( pCHS->dwBasePort + HDD_SECTOR_NUMBER), 1 );
	dwTemp    = (DWORD)( pCHS->dwCylinder & (DWORD)0xFF);
	WRITE_PORT_UCHAR( (DWORD)( pCHS->dwBasePort + HDD_CYLINDER_L), (UCHAR)dwTemp );
	dwTemp    = (DWORD)( pCHS->dwCylinder >> 8 );
	WRITE_PORT_UCHAR( (DWORD)( pCHS->dwBasePort + HDD_CYLINDER_H), (UCHAR)dwTemp );	
	dwTemp    = (DWORD)( pCHS->dwHead & 0x0F ) | (DWORD)( pCHS->dwMasterSlave << 4 ) | (DWORD)0xE0;  // 1110 0000  (LBA Mode)
	WRITE_PORT_UCHAR( (DWORD)( pCHS->dwBasePort + HDD_DRIVE_HEAD), (UCHAR)dwTemp );

	// clear event count
	if( pCHS->dwBasePort == PRIMARY_HDD_BASE )
		clear_event_count( &m_primary_ide_event );
	else
		clear_event_count( &m_secondary_ide_event );

	// send seek command
	WRITE_PORT_UCHAR( (DWORD)( pCHS->dwBasePort + HDD_COMMAND), HDD_SEEK_COMMAND );

	// wait irq
	if( pCHS->dwBasePort == PRIMARY_HDD_BASE )
		nR = wait_event( &m_primary_ide_event, 1000 );
	else
		nR = wait_event( &m_secondary_ide_event, 1000 );

	if( nR < 0 )
	{	// time out
		CrtPrintf( "HDD seek failed : timeout!\n" );
		return( -1 );
	}									 	

	return( 0 );
}

// LBA-> CHS = xHCCCCSS
static void vLBA2CHS( CHSStt *pChs, DWORD dwLBA )
{
	pChs->dwSector   = (DWORD)( dwLBA & 0xFF );
	pChs->dwCylinder = (DWORD)( (DWORD)(dwLBA >>  8  ) & 0xFFFF );
	pChs->dwHead	 = (DWORD)( (DWORD)(dwLBA >>  24 ) & 0x0F );
}	

// read sector by lba
static int read_sectors_by_lba( CHSStt *pCHS, char *pB )
{
	int		nR;
	DWORD	dwTemp;
	DWORD	i;
	//nR = seek_hdd( pCHS );  VMWare���� �������� �ʴ´�.

	// �߸��� ���� ���� �� �Լ����� ��� ���ߴµ� �װ��� �˻��ϱ� ���� ������� �ּ��� - �Լ��� ������ �˸�.
	//CrtPrintf("GetPartitionTbl  in read_sectors_by_lba\r\n");

	// send read parameter
	WRITE_PORT_UCHAR( (DWORD)( pCHS->dwBasePort + HDD_SECTOR_COUNT),  (UCHAR)pCHS->dwTotalSector );

	WRITE_PORT_UCHAR( (DWORD)( pCHS->dwBasePort + HDD_SECTOR_NUMBER), (UCHAR)pCHS->dwSector );
	dwTemp    = (DWORD)( pCHS->dwCylinder & (UCHAR)0xFF);  // Low cylinder
	WRITE_PORT_UCHAR( (DWORD)( pCHS->dwBasePort + HDD_CYLINDER_L), (UCHAR)dwTemp );
	dwTemp    = (DWORD)( pCHS->dwCylinder >> 8 );
	WRITE_PORT_UCHAR( (DWORD)( pCHS->dwBasePort + HDD_CYLINDER_H ), (UCHAR)(dwTemp & (DWORD)0xFF) );	
	dwTemp    = (DWORD)( pCHS->dwHead & 0x0F ) | (DWORD)( pCHS->dwMasterSlave << 4 ) | (DWORD)0xE0;  // 1110 0000  (LBA Mode)
	WRITE_PORT_UCHAR( (DWORD)( pCHS->dwBasePort + HDD_DRIVE_HEAD), (UCHAR)dwTemp );

	// clear event count
	if( pCHS->dwBasePort == PRIMARY_HDD_BASE )
		clear_event_count( &m_primary_ide_event );
	else
		clear_event_count( &m_secondary_ide_event );

	// Send Read Command
	WRITE_PORT_UCHAR( (DWORD)( pCHS->dwBasePort + HDD_COMMAND), (UCHAR)HDD_READ_COMMAND );

	// wait irq
	if( pCHS->dwBasePort == PRIMARY_HDD_BASE )
		nR = wait_event( &m_primary_ide_event, 1000 );
	else
		nR = wait_event( &m_secondary_ide_event, 1000 );

	//  ��� ���� ���� �д� �κ��ε�.. (�ʿ����?)

	//for( nI = 0; nI < 6; nI++ )
	//{
	//	BYTE byTe;
	//	byTe = READ_PORT_UCHAR( (DWORD)(pCHS->dwBasePort+HDD_STATUS));
	//	CrtPrintf("HDD_STATUS: %X \r\n",byTe);
	//}


	// read data from port
	if( nR < 0 )
	{
		CrtPrintf( "hdd read command(0x%X) failed!\n", HDD_READ_COMMAND );
		return( -1 );
	}

	// read data  (2003-07-26)	�� ���徿 �дٰ� vReadPortMultiWord�� �̿��Ͽ� �� ���� ��� �����͸� ����.
	//for( nI = 0; nI < (int)pCHS->dwTotalSector * 512 / 2; nI++ )
	//	vReadPortWord( (DWORD)( pCHS->dwBasePort+HDD_DATA ), (UINT16*)&pB[nI*2] );

	// ���� ���۰� Ready�� �Ǳ⸦ ��ٸ���.

	// !!!!!!!!!!!!!!!!!!!!!! ���� ���͸� ������ �����Ⱚ�� �߰��� ����. 
	//vReadPortMultiWord( (DWORD)( pCHS->dwBasePort+HDD_DATA ), (WORD*)pB, pCHS->dwTotalSector * 512 / 2 );
	for( i = 0; i < pCHS->dwTotalSector; i++)
	{
		for( ;; )
		{
			UCHAR byTe;
			byTe = 0;
			byTe = READ_PORT_UCHAR( (DWORD)(pCHS->dwBasePort+HDD_STATUS));
			if( byTe & 8 )	// DRQ bit�� Set
				break;
		}

		vReadPortMultiWord( (DWORD)( pCHS->dwBasePort+HDD_DATA ), (WORD*)(pB+i*512), 512 / 2 );
	}
	// �߸��� ���� ���� �� �Լ����� ��� ���ߴµ� �װ��� �˻��ϱ� ���� ������� �ּ���
	//CrtPrintf("GetPartitionTbl  in read_sectors_by_lba [before return]\r\n");
	return( 0 );
}

// read one sector
int read_sectors( int nDrv, DWORD dwIndex, int nTotalSector, char* pBuff )
{
	CHSStt		chs;
	int 		nR;
	DWORD		dwBasePort;


	if( nDrv <= 1 )
		dwBasePort = PRIMARY_HDD_BASE;
	else if( nDrv <= 3 )
		dwBasePort = SECONDARY_HDD_BASE;
	else if( nDrv == 4)
	{
		m_usb_read_count++;
		return usb_read_sectors(nDrv,dwIndex,nTotalSector,pBuff);
	}
	else
		return( -1 );

	m_read_count++;

	vLBA2CHS( &chs, dwIndex );
	chs.dwTotalSector = nTotalSector;
	chs.dwMasterSlave = nDrv % 2;
	chs.dwBasePort    = dwBasePort;

	nR = read_sectors_by_lba( &chs, pBuff );  

	return( nR );
}

// ���� --- �׽�Ʈ �ڵ� �Ҿ�����
// read sector by lba
static int write_sectors_by_lba( CHSStt *pCHS, char *pB )
{
	int		nR;
	DWORD	dwTemp;
	DWORD	i;

	nR = seek_hdd( pCHS );  // VMWare���� �������� �ʴ´�.

	// send read parameter
	WRITE_PORT_UCHAR( (DWORD)( pCHS->dwBasePort + HDD_SECTOR_COUNT),  (UCHAR)pCHS->dwTotalSector );
	WRITE_PORT_UCHAR( (DWORD)( pCHS->dwBasePort + HDD_SECTOR_NUMBER), (UCHAR)pCHS->dwSector );
	dwTemp    = (DWORD)( pCHS->dwCylinder & (UCHAR)0xFF);  // Low cylinder
	WRITE_PORT_UCHAR( (DWORD)( pCHS->dwBasePort + HDD_CYLINDER_L), (UCHAR)dwTemp );
	dwTemp    = (DWORD)( pCHS->dwCylinder >> 8 );
	WRITE_PORT_UCHAR( (DWORD)( pCHS->dwBasePort + HDD_CYLINDER_H ), (UCHAR)(dwTemp & (DWORD)0xFF) );	
	dwTemp    = (DWORD)( pCHS->dwHead & 0x0F ) | (DWORD)( pCHS->dwMasterSlave << 4 ) | (DWORD)0xE0;  // 1110 0000  (LBA Mode)
	WRITE_PORT_UCHAR( (DWORD)( pCHS->dwBasePort + HDD_DRIVE_HEAD), (UCHAR)dwTemp );

	// Send Write Command
	WRITE_PORT_UCHAR( (DWORD)( pCHS->dwBasePort + HDD_COMMAND), (UCHAR)HDD_WRITE_COMMAND );


	//for( ;; )
	//{
	//	UCHAR byTe;
	//	byTe = 0;
	//	byTe = READ_PORT_UCHAR( (DWORD)(pCHS->dwBasePort+HDD_STATUS));
	//	if( byTe & 8 )	// DRQ bit�� Set
	//		break;
	//}

	//vWritePortMultiWord( (DWORD)( pCHS->dwBasePort+HDD_DATA ), (WORD*)pB, pCHS->dwTotalSector * 512 / 2 );

	for( i = 0; i < pCHS->dwTotalSector; i++)
	{
		for( ;; )
		{
			UCHAR byTe;
			byTe = 0;
			byTe = READ_PORT_UCHAR( (DWORD)(pCHS->dwBasePort+HDD_STATUS));
			if( byTe & 8 )	// DRQ bit�� Set
				break;
		}

		vWritePortMultiWord( (DWORD)( pCHS->dwBasePort+HDD_DATA ), (WORD*)(pB+i*512), 512 / 2 );

	}

	// clear event count
	if( pCHS->dwBasePort == PRIMARY_HDD_BASE )
		clear_event_count( &m_primary_ide_event );
	else
		clear_event_count( &m_secondary_ide_event );

	// wait irq
	if( pCHS->dwBasePort == PRIMARY_HDD_BASE )
		nR = wait_event( &m_primary_ide_event, 1000 );
	else
		nR = wait_event( &m_secondary_ide_event, 1000 );

	// read data from port
	if( nR < 0 )
	{
		CrtPrintf( "hdd write command(0x%X) failed!\r\n", HDD_WRITE_COMMAND );
		return( -1 );
	}

	return( 0 );
}


// write one sector
int write_sectors( int nDrv, DWORD dwIndex, int nTotalSector, char *pBuff )
{
	CHSStt		chs;
	int 		nR;
	DWORD		dwBasePort;

	if( nDrv <= 1 )
		dwBasePort = PRIMARY_HDD_BASE;
	else if( nDrv <= 3 )
		dwBasePort = SECONDARY_HDD_BASE;
	else if( nDrv == 4)
	{
		m_usb_write_count++;
		return usb_write_sectors(nDrv,dwIndex,nTotalSector,pBuff);
	}
	else
		return( -1 );

	m_write_count++;

	vLBA2CHS( &chs, dwIndex );
	chs.dwTotalSector = nTotalSector;
	chs.dwMasterSlave = nDrv % 2;
	chs.dwBasePort    = dwBasePort;

	nR = write_sectors_by_lba( &chs, pBuff );  
	return( nR );
}
