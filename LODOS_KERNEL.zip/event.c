#include "event.h"

VOID clear_event_count(HEVENT* pEventHandle)
{
	*pEventHandle = INTERRUPT_CLEAR;
}

int wait_event(HEVENT* pEventHandle, DWORD dwTime)
{
	DWORD start_tick, cur_tick;

	start_tick = PsGetTickCount();
	while(*pEventHandle == INTERRUPT_CLEAR)
	{
		cur_tick = PsGetTickCount();
		if(PsGetMilliSec(cur_tick - start_tick) > dwTime)
			return -1;
	}

	return 0;
}

VOID SetEvent(HEVENT* pEventHandle)
{
	*pEventHandle = INTERRUPT_OCCURRED;
}

VOID SDelay(DWORD dwTime)
{
	DWORD start_tick, cur_tick;

	start_tick = PsGetTickCount();
	while(1)
	{
		cur_tick = PsGetTickCount();

		if(PsGetMilliSec(cur_tick - start_tick) > dwTime)
			break;
	}
}