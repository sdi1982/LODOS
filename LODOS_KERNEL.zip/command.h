#ifndef _COMMAND_H_
#define _COMMAND_H_
#include "lodos.h"

extern KERNELAPI DWORD MK_DIR(IN char* str_path, char* str_dir);
extern KERNELAPI DWORD RM_DIR(char* str_path, char* str_dir);
extern KERNELAPI DWORD DIR_0();
extern KERNELAPI DWORD DIR_1(char* path);
extern KERNELAPI DWORD TYPE(char* fileName);
extern KERNELAPI DWORD COPY(char* src_path, char* dest_path);
extern KERNELAPI VOID  HDD_DUMP( IN int nDrv, IN DWORD dwIndex, IN DWORD len);
extern KERNELAPI DWORD VOLUME_INFO_0();
extern KERNELAPI DWORD VOLUME_INFO_1(DWORD drive);
extern KERNELAPI DWORD CD(char* path);
extern KERNELAPI VOID  CUR_VOL_STRING(IN char * InString); // 2007 08 02 ������ - File �����ڸ� ���� Ŀ�� �Լ���!! 
//extern KERNELAPI DWORD api_CD(char* path);
//extern KERNELAPI DWORD api_COPY(char* src_path, char* dest_path);
#endif