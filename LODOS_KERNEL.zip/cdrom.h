#ifndef _CDROM_H_
#define _CDROM_H_

#include "lodos.h"

#define CD_DATA			0x0
#define CD_ERROR		0x01
#define CD_FEATURE		0x01
#define CD_CAUSE_OF_INT	0x02
#define CD_COUNT_L		0x04
#define CD_COUNT_H		0x05
#define CD_DRV_SELECT	0x06
#define CD_STATUS		0x07
#define CD_COMMAND		0x07

typedef struct {
	WORD	wConfig;
	WORD	rsv0[9];
	WORD	serial[10];
	WORD	rsv2[3];
	WORD	firmware[4];
	WORD	model[20];
	WORD	rsv3[512 - 47];

	//=======================//
	char		szSerial[21];
	char		szModel[41];
} CDGeometryStt;

int CheckCDBusy( DWORD dwBasePort );
int ReadCDGeometryInfo( CDGeometryStt *pGeo, DWORD dwBasePort, DWORD dwMasterSlave );

#endif /* #ifndef _CDROM_H_ */