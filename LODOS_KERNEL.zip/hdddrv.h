#ifndef _HDD_DRIVER_HEADER_FILE_
#define _HDD_DRIVER_HEADER_FILE_


/**********************************************************************************************************
*                                                INCLUDE FILES                                           *
**********************************************************************************************************/
#include "lodos.h"
/************************************************************************/
/*  Hard Disk Driver // [5/17/2007]	�ŵ���								*/
/************************************************************************/
/*
* DEFINITIONS
*/
#define DEFAULT_STACK_SIZE			(64*1024) /* 64kbytes */

#define PRIMARY_HDD_BASE			0x1F0
#define SECONDARY_HDD_BASE			0x170

#define HDD_DATA					0x0
#define HDD_FEATURE 				0x1
#define HDD_ERROR 					0x1
#define HDD_SECTOR_COUNT			0x2
#define HDD_SECTOR_NUMBER			0x3
#define HDD_CYLINDER_L				0x4
#define HDD_CYLINDER_H				0x5
#define HDD_DRIVE_HEAD				0x6
#define HDD_STATUS					0x7
#define HDD_COMMAND					0x7
#define HDD_ALT_STATUS				0x206
#define HDD_DRIVE_HEAD_STATUS		0x207

#define HDD_RECALIBRATE_COMMAND		0x10
//#define HDD_READ_COMMAND			0x21  // 0x21�� ����ϸ� VMWare���� �۵����� �ʴ´�.
#define HDD_READ_COMMAND			0x20  // 2003-04-30  READ_SECTOR(S)
#define HDD_READ_DMA_COMMAND		0xC8  
#define HDD_SEEK_COMMAND			0x70
#define HDD_IDENTIFY_COMMAND		0xEC
#define HDD_SET_FEATURE_COMMAND		0xEF
#define HDD_WRITE_COMMAND			0x30

// UDMA
#define UDMA_MODE_0_SUPPORTED	0x0001
#define UDMA_MODE_1_SUPPORTED	0x0002
#define UDMA_MODE_2_SUPPORTED	0x0004
#define UDMA_MODE_3_SUPPORTED	0x0008
#define UDMA_MODE_4_SUPPORTED	0x0010

#define UDMA_MODE_0_SET			0x0100
#define UDMA_MODE_1_SET 		0x0200
#define UDMA_MODE_2_SET 		0x0400
#define UDMA_MODE_3_SET 		0x0800
#define UDMA_MODE_4_SET 		0x1000

/*
* STRUCTURES
*/
typedef struct IDGeometryTag{
	WORD  	wConfig;
	WORD  	wCylinder;
	WORD  	wRsv1;
	WORD  	wHead;
	WORD  	wUfTrack;
	WORD  	wUfSector;
	WORD  	wSector;				// 6
	WORD  	manufacturer[3];		// 7
	WORD  	serial[10];				// 10
	WORD  	retired[3];				// 20
	WORD  	firm_ver[4];			// 23
	WORD	model[20];				// 27

	WORD	byRsv2;					// 47
	WORD	byRsv3;					// 48
	WORD	byMode;		  			// 49
	WORD	rsv_a[3];		  		// 50
	WORD	wAvailableBit;			// 53
	WORD	rsv_b[6];				// 54
	WORD	wLBASectors1; 			// 60
	WORD	wLBASectors2; 			// 61

	WORD	rsv_c[26];	  			// 62
	WORD	wUDMAFlag;    			// 88
	WORD	rsv_d[68];	  			// 89

	WORD	rsv4[100];	  			// 156 (256 Words = 512 bytes)

	// ���� �׳� �߸ŷ� ���� ��.
	////////////////////////////////
	CHAR	szManufacturer[7];	  
	CHAR    szModel[41];		  
	DWORD   dwSize;				  
	////////////////////////////////
} IDEGeometryStt;

typedef struct  {
	DWORD 	dwCylinder;
	DWORD 	dwHead;
	DWORD 	dwSector;
	DWORD 	dwTotalSector;
	DWORD 	dwBasePort;
	DWORD 	dwMasterSlave;
}CHSStt;


/************************************************************************/
/* For Hdd Process, Thread                                              */
/************************************************************************/
typedef enum _HDD_JOB_TYPE {
	HDD_READ_SECTOR,
	HDD_WRITE_SECTOR,
} HDD_JOB_TYPE;

typedef struct _HDD_JOB_ITEM {
	HDD_JOB_TYPE			type;
	WORD					sector;
	BYTE					numbers_of_sectors;
	BYTE					*pt_data;

	HANDLE					thread;
} HDD_JOB_ITEM, *PHDD_JOB_ITEM;

#define HDD_JOB_ITEM_Q_SIZE		32
typedef struct _HDD_JOB_ITEM_Q {
	BYTE				cnt;

	BYTE				head;
	BYTE				tail;
	HDD_JOB_ITEM		queue[HDD_JOB_ITEM_Q_SIZE];
} HDD_JOB_ITEM_Q, *PHDD_JOB_ITEM_Q;

/*
* GLOBAL FUNCTIONS
*/
VOID Hdd_IRQ_Handler(VOID);
static int HddRecalibrate(DWORD dwBasePort, DWORD byMasterSlave );
/*
* INTERNEL FUNCTIONS
*/
UINT IDEAutoDetection(VOID);

static int CheckIDEHddBusy( DWORD dwBasePort );
static int GetUDMASetNumber(IDEGeometryStt *pGeo );
static int GetUDMASupportNumber(IDEGeometryStt *pGeo );


void vSwapWORDArray( WORD *pW, int nTotal );
void vCutAppendedSpace( char *pS );
/**********************************************************************************************************
*                                               DIRVER FUNCTIONS                                         *
**********************************************************************************************************/
extern int read_sectors( int nDrv, DWORD dwIndex, int nTotalSector, char *pBuff );
extern int write_sectors( int nDrv, DWORD dwIndex, int nTotalSector, char *pBuff );
#endif /* #ifndef _HDD_DRIVER_HEADER_FILE_ */