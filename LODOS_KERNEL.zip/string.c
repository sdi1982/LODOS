#include "string.h"

#ifndef NULL
# define NULL ((void *)0)
#endif

void* memset(void *pSource, int ch, size_t size)
{
	size_t i;

	for(i=0; i<size; i++)
		*(((char *)pSource)+i) = (char)ch;

	return pSource;
}

char *strlwr(char *str)
{
	char *cp = str;

	while(*cp != '\0') {
		if(*cp >= 'A' && *cp <= 'Z')
			*cp = *cp-'A' + 'a';
		cp++;
	}

	return str;
}

char *strupr(char *str)
{
	char *cp = str;

	while(*cp != '\0') {
		if(*cp >= 'a' && *cp <= 'z')
			*cp = *cp-'a' + 'A';
		cp++;
	}

	return str;
}

/* codes from Linux */
int strcmp(const char *cs, const char *ct)
{
	char __res;

	while(1) {
		if ((__res = *cs - *ct++) != 0 || !*cs++)
			break;
	}

	return __res;
}

/* codes from Linux */
size_t strlen(const char * s)
{
	const char *sc;

	for (sc = s; *sc != '\0'; ++sc)
		/* nothing */;
	return sc - s;
}

/* codes from Linux */
void *memcpy(void *dest, const void *src, size_t count)
{
	char *tmp = (char *) dest, *s = (char *) src;

	while (count--)
		*tmp++ = *s++;

	return dest;
}

/* codes from Linux */
char * strrchr(const char * s, int c)
{
       const char *p = s + strlen(s);
       do {
           if (*p == (char)c)
               return (char *)p;
       } while (--p >= s);
       return NULL;
}

/* codes from Linux */
char * strcpy(char * dest,const char *src)
{
	char *tmp = dest;

	while ((*dest++ = *src++) != '\0')
		/* nothing */;
	return tmp;
}

/* codes from Linux */
char * strcat(char * dest, const char * src)
{
	char *tmp = dest;

	while (*dest)
		dest++;
	while ((*dest++ = *src++) != '\0')
		;

	return tmp;
}

/************************************************************************/
/* �ŵ���	    [5/17/2007]                                             */
/************************************************************************/
int is_char(const char ch )
{
	if( 'a' <= ch  && ch <= 'z' )
		return( 1 );
	if( 'A' <= ch  && ch <= 'Z' )
		return( 1 );
	return( 0 );
}		   

int memcmp(const void* pD,const void *pS, int lSize )
{
	long lX;
	unsigned char *pDest = (unsigned char*)pD;
	unsigned char *pSrc  = (unsigned char*)pS;

	for( lX = 0; lX < lSize; lX++ )
	{
		if( pDest[lX] > pSrc[lX] )
			return( 1 );
		else if( pDest[lX] < pSrc[lX] )
			return( -1 );
	}

	return( 0 );
}

void wcstombs(char* final,const unsigned short* filename, int num)
{
	int i;
	for(i = 0; i <num; i++)
	{
		*(final+i) = (char)*(filename+i);
	}
}


int  strcmpi(const char *pA,const char *pB )
{
	char szA[512], szB[512];

	strcpy( szA, pA );
	strcpy( szB, pB );
	strlwr( szA );
	strlwr( szB );

	return( strcmp( szA, szB ) );
}
// 10, 0 = 1, 10, 1 = 10, 10, 2 = 100, 10, 3 = 1000...
int pow(int num, int exp)
{
	int i;
	int count = 1;

	for( i = 0; i< exp; i++)
	{
		count = count * num;
	}

	return count;
}

int atoi(const char *str)
{
	int length=0,sum=0,i=0;
	const char *ptemp = 0;

	ptemp=str;

	if ((str[0] != '0') && ((str[1] != 'x') || (str[1] != 'X'))){
		// 10���� �� ���.

		if('0'<=*str&&*str<='9'){              //ó�����ڿ��� ������ char ���� 
			while(*str!=0){                    //1111bbbb ������ char ���� ������ ���̸� ���Ѵ�.
				if('0'<=*str&&*str<='9'){
					length++;
					str++;
				}
				else
					break;
			}

			str=ptemp;                          //ó�� �ּ����� �ʱ�ȭ.

			while(i!=length){
				sum=sum*10+*(str+i)-48;        //�ڸ����� ���� 10��ȭ.
				i++;
			}
			return sum;
		}
		else
			return sum;
	}

	else
	{

		// 16���� �� ���
		if (!(str[0] == '0' && (str[1] == 'x' || str[1] == 'X')))
			return 0;

		str += 2;
		if(('0' <= *str && *str <= '9') || ('a' <= *str && *str <= 'f') || ('A' <= *str && *str <= 'F')){
			while(*str != 0){
				if(('0' <= *str && *str <= '9') || ('a' <= *str && *str <= 'f') || ('A' <= *str && *str <= 'F')){
					length++;
					str++;
				}
				else
					break;
			}

			str = ptemp + 2;

			while(i!=length){
				sum=sum*16;
				if(('0' <= *(str+i) && *(str+i) <= '9'))
					sum += *(str+i)-48;
				if('a' <= *(str+i) && *(str+i) <= 'f')
					sum += *(str+i)-97 + 10;
				if('A' <= *(str+i) && *(str+i) <= 'F')
					sum += *(str+i)-65 + 10;
				i++;
			}

			return sum;
		}
		else sum;

	}

	return -1;
}
